local hunteeringdeathmatch = {
	UseReadyRoom = true,
	UseRounds = true,
	AllowLateJoiners = false,
	
	-- Limit dead bodies and dropped items.
	MaxDeadBodies = 8,
	MaxDroppedItems = 32,
	
	-- override other values
	
	StringTables = { "Hunteeringdeathmatch" },

	MissionTypeDescription = "[PvP/PVE/PVPVE] Will you be a hunter or the hunted? Collect the intel and exfil at the end of mission time.",
	-- displayed on mission selection screen

	PlayerTeams = {
		Deathmatch = {
			TeamId = 1,
			Loadout = "HunteeringDeathmatch",
		},
	},
	
	BotTag = "DeathmatchBot",

	Settings = {
		RoundTime = {
			Min = 5,
			Max = 60,
			Value = 20,
			AdvancedSetting = false,
		},
		-- number of minutes in each round
		
		
		BotCount = {
			Min = 0,
			Max = 8,
			Value = 0,
			AdvancedSetting = false,
		},
		
		-- ADDED IR code
		
		Difficulty = {
			Min = 0,
			Max = 4,
			Value = 2,
			AdvancedSetting = false,
		},
		
		
		DisplaySearchLocations = {
			Min = 0,
			Max = 5,
			Value = 5,
			AdvancedSetting = false,
		},
		
		
		ExfilTime = {
			Min = 1,
			Max = 5,
			Value = 1,
			AdvancedSetting = false,
		},
		
		
		ProximityAlert = {
			Min = 0,
			Max = 1,
			Value = 0,
			AdvancedSetting = true,
		},
		
		PlayerTeamUp = {
			Min = 0,
			Max = 1,
			Value = 0,
			AdvancedSetting = true,
		},
		
		SearchTime = {
			Min = 1,
			Max = 60,
			Value = 10,
			AdvancedSetting = true,
		},
		
		-- END of IR code
		
	},
	
	InsertionPoints = {},
	
	PlayerStarts = {},
	AISpawnPoints = {},
	RecentlyUsedPlayerStarts = {},
	MaxRecentlyUsedPlayerStarts = 0,
	TooCloseSq = 1000000,	
	
	-- player score types includes score types for both attacking and defending players
	PlayerScoreTypes = {
		WonRound = {
			Score = 10,
			OneOff = true,
			Description = "You won the round!",
		},
		Kills = {
			Score = 1,
			OneOff = false,
			Description = "Kills",
		},
	},
	
	NumAIToSpawn = 0,
	AIRespawnTime = 0.1,
	NextSpawnIndex = 1,
	CheckBotInterval = 5.0,
	FragDisplayUpdateInterval = 2.0,
	
	CheckPlayerKillCountQueue = {},
	
	
	-- ADDED IR code
	
	MissionLocationMarkers = {},
	-- for creating rings on ops board showing probably location of laptop
	
	ExtractionPoints = {},
	ExtractionPointMarkers = {},
	ExtractionPointIndex = 0,
	
	Laptops = {},
	
	LaptopTag = "TheIntelIsALie",
	-- this variable is relied on by the IntelTarget.lua script - do not delete
	
	RandomLaptopIndex = nil,
	
	LaptopLocationNameList = {},
	-- the true location name will be first in this list, otherwise randomly shuffled
		
	LaptopObjectiveMarkerName = "",
	-- text displayed on search location marker (currently none)
	
	CurrentSearchObjectives = {},
	
	TeamExfilWarning = false,
	
	CompletedARound = true,
	
	LaptopProximityAlertRadius = 5.0,
	-- get a warning within 5 m of a laptop
	
	TestAllLaptops = false,	
	botsadded = false, -- bool to allow bots to stop spawning after the start of the game
	
	
	-- END of IR code
}


function hunteeringdeathmatch:DumbTableCopy(MyTable)
	local ReturnTable = {}
	
	for Key, TableEntry in ipairs(MyTable) do
		table.insert(ReturnTable, TableEntry)
	end
	
	return ReturnTable
end


function hunteeringdeathmatch:PreInit()
	self.PlayerStarts = gameplaystatics.GetAllActorsOfClass('GroundBranch.GBPlayerStart')
	self.AISpawnPoints = gameplaystatics.GetAllActorsOfClass('GroundBranch.GBAISpawnPoint')
	if #self.AISpawnPoints == 0 then
		print("hunteering: no AI spawn points found, so can't play with AI making up numbers.")
	end
	
	
	-- setup extraction points
	
	-- ADDED IR code
	
	self.ExtractionPoints = gameplaystatics.GetAllActorsOfClass('/Game/GroundBranch/Props/GameMode/BP_ExtractionPoint.BP_ExtractionPoint_C')
	
	for i = 1, #self.ExtractionPoints do
		local Location = actor.GetLocation(self.ExtractionPoints[i])
		local ExtractionMarkerName = self:GetModifierTextForObjective( self.ExtractionPoints[i] ) .. "EXTRACTION"
		-- allow the possibility of down chevrons, up chevrons, level numbers, etc
				
		self.ExtractionPointMarkers[i] = gamemode.AddObjectiveMarker(Location, self.PlayerTeams.Deathmatch.TeamId, ExtractionMarkerName, "Extraction", false)
		-- NB new penultimate parameter of MarkerType ("Extraction" or "MissionLocation", at present)
	end
	
	
	-- now sort laptops
	
	self.Laptops = gameplaystatics.GetAllActorsOfClass('/Game/GroundBranch/Props/Electronics/MilitaryLaptop/BP_Laptop_Usable.BP_Laptop_Usable_C')

	-- set up laptop intel rings for ops board
	local AllInsertionPoints = gameplaystatics.GetAllActorsOfClass('GroundBranch.GBInsertionPoint')
	
	self.MissionLocationMarkers = {}
	
	for i = 1, #AllInsertionPoints do
		if actor.HasTag( AllInsertionPoints[i], "Defenders" ) then
			local Location = actor.GetLocation(AllInsertionPoints[i])
			local InsertionPointName = gamemode.GetInsertionPointName(AllInsertionPoints[i])
			local MarkerName = self.LaptopObjectiveMarkerName
			
			MarkerName = self:GetModifierTextForObjective( AllInsertionPoints[i] ) .. MarkerName
			-- this checks tags on the specified actor and produces a prefix if appropriate, for interpretation within the WBP_ObjectiveMarker widget
			-- you can give the insertion point tags to add the relevant symbol before "INTEL?"
			
			self.MissionLocationMarkers[InsertionPointName] = gamemode.AddObjectiveMarker(Location, self.PlayerTeams.Deathmatch.TeamId, MarkerName, "MissionLocation", false)
			-- NB new penultimate parameter of MarkerType ("Extraction" or "MissionLocation", at present)
		end
	end
	
	-- END of IR code
	
	self.MaxRecentlyUsedPlayerStarts = #self.PlayerStarts / 2
	
	gamemode.SetPlayerScoreTypes( self.PlayerScoreTypes )
	gamemode.SetTeamAttitude( self.PlayerTeams.Deathmatch.TeamId, self.PlayerTeams.Deathmatch.TeamId, 'hostile' )
	-- just in case needed for AI
end


function hunteeringdeathmatch:GetModifierTextForObjective( TaggedActor )
	-- consider moving to gamemode
			
	if actor.HasTag( TaggedActor, "AddUpArrow") then
		return "(U)" 
	elseif actor.HasTag( TaggedActor, "AddDownArrow") then
		return "(D)" 
	elseif actor.HasTag( TaggedActor, "AddUpStaircase") then
		return "(u)" 
	elseif actor.HasTag( TaggedActor, "AddDownStaircase") then
		return "(d)"
	elseif actor.HasTag( TaggedActor, "Add1") then
		return "(1)" 
	elseif actor.HasTag( TaggedActor, "Add2") then
		return "(2)" 
	elseif actor.HasTag( TaggedActor, "Add3") then
		return "(3)"
	elseif actor.HasTag( TaggedActor, "Add4") then
		return "(4)" 
	elseif actor.HasTag( TaggedActor, "Add5") then
		return "(5)" 
	elseif actor.HasTag( TaggedActor, "Add6") then
		return "(6)" 
	elseif actor.HasTag( TaggedActor, "Add7") then
		return "(7)" 
	elseif actor.HasTag( TaggedActor, "Add8") then
		return "(8)" 
	elseif actor.HasTag( TaggedActor, "Add9") then
		return "(9)" 
	elseif actor.HasTag( TaggedActor, "Add0") then
		return "(0)" 
	elseif actor.HasTag( TaggedActor, "Add-1") then
		return "(-)"
	elseif actor.HasTag( TaggedActor, "Add-2") then
		return "(=)"
	end
		
	return ""
end

function hunteeringdeathmatch:PostInit()
	gamemode.AddGameObjective(self.PlayerTeams.Deathmatch.TeamId, "RetrieveIntel", 1)
	gamemode.AddGameObjective(self.PlayerTeams.Deathmatch.TeamId, "BeOnExtractionAtTheTimeLimit", 1)
	gamemode.AddGameObjective(self.PlayerTeams.Deathmatch.TeamId, "OptionalKillAllOpposition", 2)
	
end


function hunteeringdeathmatch:PlayerGameModeRequest(PlayerState, Request)
	if PlayerState ~= nil then
		if Request == "join"  then
			gamemode.EnterPlayArea(PlayerState)
		end
	end
end


function hunteeringdeathmatch:WasRecentlyUsed(PlayerStart)
	for i = 1, #self.RecentlyUsedPlayerStarts do
		if self.RecentlyUsedPlayerStarts[i] == PlayerStart then
			return true
		end
	end
	return false
end


function hunteeringdeathmatch:RandomiseObjectives()
	-- called to reset and randomise the mission objectives

	-- first, pick a random extraction point
	self.botsadded = false
	self.ExtractionPointIndex = umath.random(#self.ExtractionPoints)
	-- this is the current extraction point

	for i = 1, #self.ExtractionPoints do
		local bActive = (i == self.ExtractionPointIndex)
		actor.SetActive(self.ExtractionPointMarkers[i], bActive)
		actor.SetActive(self.ExtractionPoints[i], false)
		-- set extraction marker to active but don't turn on flare yet
	end
	
	
	gamemode.ClearGameObjectives()
	gamemode.ClearSearchLocations()
	
	self.CurrentSearchObjectives = {}
	gamemode.AddGameObjective(self.PlayerTeams.Deathmatch.TeamId, "RetrieveIntel", 1)
	gamemode.AddGameObjective(self.PlayerTeams.Deathmatch.TeamId, "BeOnExtractionAtTheTimeLimit", 1)
	gamemode.AddGameObjective(self.PlayerTeams.Deathmatch.TeamId, "OptionalKillAllOpposition", 2)
	
	local AllInsertionPoints = gameplaystatics.GetAllActorsOfClass('GroundBranch.GBInsertionPoint')
	
	for i, InsertionPoint in ipairs(AllInsertionPoints) do
		-- any insertion point matching a tag of the extraction point will be disabled (i.e. is in proximity)
		
		if actor.GetTeamId(InsertionPoint) == self.PlayerTeams.Deathmatch.TeamId then
			local InsertionPointName = gamemode.GetInsertionPointName(InsertionPoint)
			
			if self.Settings.PlayerTeamUp.Value == 1 then
				bActive = true
	--		elseif actor.HasTag( self.ExtractionPoints[self.ExtractionPointIndex], InsertionPointName) then
	--			bActive = false
			else 
				bActive = false
			end

			actor.SetActive(InsertionPoint, bActive)
			actor.SetTeamId(InsertionPoint, self.PlayerTeams.Deathmatch.TeamId)
		end
	end

	-- second, pick a random laptop

	self.LaptopLocationNameList = {}
	local AllFakeLocationNames = {}
	local LocationName

	self.RandomLaptopIndex = umath.random(#self.Laptops);
	
	print("----picking laptop " .. self.RandomLaptopIndex .. " (" .. actor.GetName(self.Laptops[self.RandomLaptopIndex]) .. ") out of " .. #self.Laptops .. " possible")
	
	--actor.AddTag(self.Laptops[self.RandomLaptopIndex], self.LaptopTag)
	LocationName = self:GetInsertionPointNameForLaptop(self.Laptops[self.RandomLaptopIndex])
	table.insert(self.LaptopLocationNameList, LocationName)
			
	if not self.TestAllLaptops then
			
		for i = 1, #self.Laptops do
			--actor.SetActive(self.Laptops[i], true)
			if (i == self.RandomLaptopIndex) then
				actor.AddTag(self.Laptops[i], self.LaptopTag)
				actor.SetActive(self.Laptops[i], true)
				-- make laptop visible and usable
			else
				actor.SetActive(self.Laptops[i], false)
				-- make laptop disappear
				
				actor.RemoveTag(self.Laptops[i], self.LaptopTag)
				LocationName = self:GetInsertionPointNameForLaptop(self.Laptops[i])
				if LocationName ~= self.LaptopLocationNameList[1] then
					self:AddToTableIfNotAlreadyPresent( AllFakeLocationNames, LocationName )
				end
			end
		end
	
	else

		for i = 1, #self.Laptops do
			actor.AddTag(self.Laptops[i], self.LaptopTag)
			actor.SetActive(self.Laptops[i], true)
				-- make laptop visible and usable
				
			LocationName = self:GetInsertionPointNameForLaptop(self.Laptops[i])
			if LocationName ~= self.LaptopLocationNameList[1] then
				self:AddToTableIfNotAlreadyPresent( AllFakeLocationNames, LocationName )
			end
		end
	
	end
	
	for i = #AllFakeLocationNames, 1, -1 do
		local j = umath.random(i)
		AllFakeLocationNames[i], AllFakeLocationNames[j] = AllFakeLocationNames[j], AllFakeLocationNames[i]
		table.insert(self.LaptopLocationNameList, AllFakeLocationNames[i])
	end
	-- LaptopLocationNames contains random sequence of laptop locations, with the true location at [1]
	
	local NumberOfSearchLocations = self:GetNumberOfSearchLocations()
	
	for i = 1, #self.LaptopLocationNameList do
		local bActive
		if i <= NumberOfSearchLocations then
			bActive = true
		else
			bActive = false
		end
		
		actor.SetActive( self.MissionLocationMarkers[ self.LaptopLocationNameList[i] ], bActive )
	end
	
	if math.min( #self.LaptopLocationNameList, NumberOfSearchLocations ) > 3 then
	-- just too many locations
		local NewObjective = "The marked area"
		table.insert(self.CurrentSearchObjectives, NewObjective)
		gamemode.AddSearchLocation(self.PlayerTeams.Deathmatch.TeamId, NewObjective, 1)
	else
		local LocationIndices = {}

		-- this is convoluted but we can't shuffle order of LaptopLocationNameList because that screws up AI spawns
		for i = 1, math.min( #self.LaptopLocationNameList, NumberOfSearchLocations ) do
			LocationIndices[i] = i
		end
		
		-- now one last shuffly thing to create objective names
		for i = math.min( #self.LaptopLocationNameList, NumberOfSearchLocations ), 1, -1 do
			local j = umath.random(i)
			LocationIndices[i], LocationIndices[j] = LocationIndices[j], LocationIndices[i]
			
			local NewObjective = self.LaptopLocationNameList[ LocationIndices[i] ]
			table.insert(self.CurrentSearchObjectives, NewObjective)
			gamemode.AddSearchLocation(self.PlayerTeams.Deathmatch.TeamId, NewObjective, 1)
			-- need to add objectives in random order else attackers get a big clue...
		end
	end

	
end



function hunteeringdeathmatch:AddToTableIfNotAlreadyPresent( AllLocationNames, NewLocationName )
	if NewLocationName ~= nil then
		for _, LocationName in ipairs(AllLocationNames) do
			if LocationName == NewLocationName then
				return
			end
		end

		table.insert( AllLocationNames, NewLocationName )
	end
end


function hunteeringdeathmatch:IsItemInTable( TableToCheck, ItemToCheck )
	-- not actually used right now
	for _, TableItem in ipairs(TableToCheck) do
		if TableItem == ItemToCheck then
			return true
		end
	end
	return false
end


function hunteeringdeathmatch:GetInsertionPointNameForLaptop(Laptop)
	local AllInsertionPoints = gameplaystatics.GetAllActorsOfClass('GroundBranch.GBInsertionPoint')
	local InsertionPointName

	for i, InsertionPoint in ipairs(AllInsertionPoints) do
		if actor.HasTag(InsertionPoint, "Defenders") then
			InsertionPointName = gamemode.GetInsertionPointName(InsertionPoint)
			if actor.HasTag(Laptop, InsertionPointName) then
				return InsertionPointName
			end
		end
	end
	
	self:ReportError("Selected laptop did not have a tag corresponding to a defender insertion point, so no intel can be provided.")
	return nil
end


function hunteeringdeathmatch:GetNumberOfSearchLocations()
		-- 0 = none
		-- 1 = one (true location)
		-- 2 = two
		-- 3 = half
		-- 4 = all but one
		-- 5 = all
		
	if self.Settings.DisplaySearchLocations.Value <= 2 then
		return self.Settings.DisplaySearchLocations.Value
	elseif self.Settings.DisplaySearchLocations.Value == 3 then
		return math.floor(#self.LaptopLocationNameList / 2)
		-- round down
	elseif self.Settings.DisplaySearchLocations.Value == 4 then
		return #self.LaptopLocationNameList - 1
	else
		return #self.LaptopLocationNameList
	end
	
	return 2
	-- shouldn't get here
end


function hunteeringdeathmatch:RateStart(PlayerStart)
	local StartLocation = actor.GetLocation(PlayerStart)
	local PlayersWithLives = gamemode.GetPlayerListByLives(0, 1, false)
	local DistScalar = 5000
	
	if self.Settings.PlayerTeamUp.Value == 1 then
		DistScalar = 500
	end
	
	local ClosestDistSq = DistScalar * DistScalar

	for i = 1, #PlayersWithLives do
		local PlayerCharacter = player.GetCharacter(PlayersWithLives[i])

		-- May have lives, but no character, alive or otherwise.
		if PlayerCharacter ~= nil then
			local PlayerLocation = actor.GetLocation(PlayerCharacter)
			local DistSq = vector.SizeSq(StartLocation - PlayerLocation)
			if DistSq < self.TooCloseSq then
				return -10.0
			end
			
			if DistSq < ClosestDistSq then
				ClosestDistSq = DistSq
			end
		end
	end
	
	return math.sqrt(ClosestDistSq) / DistScalar * umath.random(45.0, 55.0)
end


function hunteeringdeathmatch:GetSpawnInfo(PlayerState)
	if self.Settings.PlayerTeamUp.Value == 1 then
		return
	else
		return self:GetBestSpawn()
	end
end


function hunteeringdeathmatch:GetBestSpawn()
	local StartsToConsider = {}
	local BestStart = nil
	
	for i, PlayerStart in ipairs(self.PlayerStarts) do
		if not self:WasRecentlyUsed(PlayerStart) then
			table.insert(StartsToConsider, PlayerStart)
		end
	end
	
	local BestScore = 0
	
	for i = 1, #StartsToConsider do
		local Score = self:RateStart(StartsToConsider[i])
		if Score > BestScore then
			BestScore = Score
			BestStart = StartsToConsider[i]
		end
	end
	
	if BestStart == nil then
		BestStart = StartsToConsider[umath.random(#StartsToConsider)]
	end
	
	if BestStart ~= nil then
		table.insert(self.RecentlyUsedPlayerStarts, BestStart)
		if #self.RecentlyUsedPlayerStarts > self.MaxRecentlyUsedPlayerStarts then
			table.remove(self.RecentlyUsedPlayerStarts, 1)
		end
	end
	
	return BestStart
end


function hunteeringdeathmatch:PlayerInsertionPointChanged(PlayerState, InsertionPoint)
	print("hunteering:PlayerInsertionPointChanged()")

	--timer.Set("CheckReadyUp", self, self.CheckReadyUpTimer, 0.25, false) -- NOTE: might need to change back
	
	if InsertionPoint == nil then
		timer.Set("CheckReadyDown", self, self.CheckReadyDownTimer, 0.1, false);
	else
		timer.Set("CheckReadyUp", self, self.CheckReadyUpTimer, 0.25, false);
	end
	

end


function hunteeringdeathmatch:PlayerReadyStatusChanged(PlayerState, ReadyStatus)
	
	if ReadyStatus ~= "WaitingToReadyUp" then
		if gamemode.GetRoundStage() == "WaitingForReady" or gamemode.GetRoundStage() == "ReadyCountdown" then
			timer.Set("CheckReadyUp", self, self.CheckReadyUpTimer, 0.25, false)
		else
			if gamemode.PrepLatecomer(PlayerState) then
				gamemode.EnterPlayArea(PlayerState)
			end
		end
	end
end


function hunteeringdeathmatch:CheckReadyUpTimer()
-- this is not called/considered any more

	print("hunteering:CheckReadyUpTimer()")
	if gamemode.GetRoundStage() == "WaitingForReady" or gamemode.GetRoundStage() == "ReadyCountdown" then
		local ReadyPlayerTeamCounts = gamemode.GetReadyPlayerTeamCounts(true)
		local PlayersReady = ReadyPlayerTeamCounts[self.PlayerTeams.Deathmatch.TeamId]
		
	
		print("PlayersReady = " .. PlayersReady .. " from max of " .. gamemode.GetPlayerCount(true))
	
		if PlayersReady >= gamemode.GetPlayerCount(true) then
			gamemode.SetRoundStage("PreRoundWait")
		elseif PlayersReady > 0 then
		-- require at least two players to start game
			gamemode.SetRoundStage("ReadyCountdown")
			--gamemode.SetRoundStage("PreRoundWait")
		end
	end
	
	if gamemode.GetRoundStage() == "ReadyCountdown" then
		local ReadyPlayerTeamCounts = gamemode.GetReadyPlayerTeamCounts(true)
	
		if ReadyPlayerTeamCounts[self.PlayerTeams.Deathmatch.TeamId] < 1 then
			gamemode.SetRoundStage("WaitingForReady")
		end
	end
end

function hunteeringdeathmatch:CheckReadyDownTimer()
	if gamemode.GetRoundStage() == "ReadyCountdown" then
		local ReadyPlayerTeamCounts = gamemode.GetReadyPlayerTeamCounts(true)
	
		if ReadyPlayerTeamCounts[self.PlayerTeams.Deathmatch.TeamId] < 1 then
			gamemode.SetRoundStage("WaitingForReady")
		end
	end
end


function hunteeringdeathmatch:PlayerEnteredPlayArea(PlayerState)
	if gamemode.GetRoundStage() == "WaitingForReady" or gamemode.GetRoundStage() == "ReadyCountdown" then
		gamemode.SetRoundStage("PreRoundWait")
	end
end


function hunteeringdeathmatch:OnRoundStageSet(RoundStage)
	print("hunteering:OnRoundStageSet() - new stage " .. RoundStage)
	

	if RoundStage == "WaitingForReady" then
		
		timer.Clear("SpawnAI")
		timer.ClearAll()
		self.NumAIToSpawn = 0
		ai.CleanUp(self.BotTag)
	
		CheckPlayerKillCountQueue = {}
		gamemode.ClearGameStats()
	--	gamemode.ClearGameObjectives()	
	--	gamemode.AddGameObjective(self.PlayerTeams.Deathmatch.TeamId, "RetrieveIntel", 1)
	--	gamemode.AddGameObjective(self.PlayerTeams.Deathmatch.TeamId, "BeOnExtractionAtTheTimeLimit", 1)
	--	gamemode.AddGameObjective(self.PlayerTeams.Deathmatch.TeamId, "Optional:KillAllOpposition", 1)
		
		self.TeamExfilWarning = false
		
		if self.CompletedARound then
		
			self:RandomiseObjectives()
		end
		
		
		self.CompletedARound = false

		gamemode.BroadcastGameMessage(" ", "Engine", -0.5)
		-- clear the engine text (summary of frag leader)
		
	elseif RoundStage == "PreRoundWait" then
		timer.Set("CheckBotNumbers", self, self.CheckBotNumbersTimer, self.CheckBotInterval, true)
		self:CheckBotNumbersTimer()
		
		gamemode.SetDefaultRoundStageTime("InProgress", self.Settings.RoundTime.Value)
		
		-- set up watch stuff
		if self.Settings.ProximityAlert.Value == 1 and self.RandomLaptopIndex ~= nil then
			--print("Setting up watch proximity alert data")
			gamemode.SetWatchMode( "IntelRetrieval", false, false, false, false )
			gamemode.ResetWatch()
			gamemode.SetCaptureZone( self.LaptopProximityAlertRadius, 0, 255, true )
			-- cap radius, cap height, team ID, spherical zone? (ignore height)
			local NewLaptopLocation = actor.GetLocation( self.Laptops[self.RandomLaptopIndex] )
			gamemode.SetObjectiveLocation( NewLaptopLocation ) 
			--print("Setting objective location to (" .. NewLaptopLocation.x .. ", " .. NewLaptopLocation.y .. ", " .. NewLaptopLocation.z .. ")")
		end
		-- watch is set up to create a proximity alert when within <LaptopProximityAlertRadius> m of the laptop
		-- need to update this as ops board setting may have changed - have to do this before RoundStage InProgress to be effective
	
	elseif RoundStage == "PostRoundWait" then
		-- remove bots, as they can't be frozen

		timer.Clear("CheckBotNumbers")
		timer.Clear("DisplayFrags")
		timer.Clear("SpawnAI")
		timer.Clear("EndRoundTimer")
		CheckPlayerKillCountQueue = {}
		self.NumAIToSpawn = 0
		ai.CleanUp(self.BotTag)

		local FreezeTime = gamemode.GetRoundStageTime()
		local HumanPlayers = gamemode.GetPlayerList(self.PlayerTeams.Deathmatch.TeamId, true)
		for _,PlayerState in ipairs(HumanPlayers) do
		--	player.FreezePlayer(PlayerState, FreezeTime)
		-- the aim was to stop people getting higher kills in the post round period
		-- best thing is to fix FreezePlayer so it stops all weapons firing
		-- second best is to comment this out and ignore until after 1032
		end
		
		self.CompletedARound = true
	
	end
end


function hunteeringdeathmatch:CreateAIOverTime(NumAI)
	if #self.AISpawnPoints == 0 then
		return
	end
	
	if self.botsadded == false then  -- disables bots after first spawn
		self.NumAIToSpawn = self.NumAIToSpawn + NumAI
		
		timer.Clear("SpawnAI")
		timer.Set("SpawnAI", self, self.SpawnAITimer, self.AIRespawnTime, false)
		self:SpawnAITimer()
		self.botsadded = true
	end
end


function hunteeringdeathmatch:SpawnAITimer()
	local AIPlayerList = ai.GetControllers('GroundBranch.GBAIController', self.BotTag, 255, 255)
	local HumanPlayerList = gamemode.GetPlayerList(self.PlayerTeams.Deathmatch.TeamId, true)
	local AIPlayers = #AIPlayerList
	local HumanPlayers = #HumanPlayerList
	local TotalPlayers = AIPlayers + HumanPlayers
	-- recheck player counts
	
	if self.Settings.BotCount.Value > 0  and self.NumAIToSpawn>0 then
		local BestPlayerStart = self:GetBestSpawn()
		local SpawnTransform = {}
		SpawnTransform.Location = actor.GetLocation( BestPlayerStart )
		SpawnTransform.Rotation = actor.GetRotation( BestPlayerStart )
		
		local VirtualAISpawnPoint = self.AISpawnPoints[ self.NextSpawnIndex ]
		self.NextSpawnIndex = self.NextSpawnIndex + 1
		if self.NextSpawnIndex > #self.AISpawnPoints then
			self.NextSpawnIndex = 1
		end

		actor.SetTeamId( VirtualAISpawnPoint, 0 )

		ai.CreateWithTransform(	VirtualAISpawnPoint, SpawnTransform, self.BotTag, 2.0 );
		-- transform, ai tag, freeze time
	
		self.NumAIToSpawn = self.NumAIToSpawn - 1
		if self.NumAIToSpawn > 0 then
			timer.Set("SpawnAI", self, self.SpawnAITimer, self.AIRespawnTime, false)
		end
	else
		self.NumAIToSpawn = 0
	end
end


function hunteeringdeathmatch:CheckBotNumbersTimer()
	if #self.AISpawnPoints == 0 then
		return
	end

	local AIPlayerList = ai.GetControllers('GroundBranch.GBAIController', self.BotTag, 255, 255)
	local HumanPlayerList = gamemode.GetPlayerList(self.PlayerTeams.Deathmatch.TeamId, true)
	local AIPlayers = #AIPlayerList
	local HumanPlayers = #HumanPlayerList
	local TotalPlayers = AIPlayers + HumanPlayers
	
	if self.Settings.BotCount.Value > 0 then
		local BotsToAdd = self.Settings.BotCount.Value
		self:CreateAIOverTime(BotsToAdd)
	else 
		timer.Clear("SpawnAI")
	end
	
	--[[
	if (TotalPlayers +  self.NumAIToSpawn) < self.Settings.MinimumPlayerCount.Value then
	
		local BotsToAdd = self.Settings.BotCount.Value
		self:CreateAIOverTime(BotsToAdd)
		
	elseif TotalPlayers + self.NumAIToSpawn > self.Settings.MinimumPlayerCount.Value then
		
		local NumBots = self.NumAIToSpawn  + TotalPlayers - HumanPlayers
		local BotsToKill = math.min( NumBots, TotalPlayers - self.Settings.MinimumPlayerCount.Value)
		
		self.NumAIToSpawn = math.max( 0, self.NumAIToSpawn - BotsToKill )
		if self.NumAIToSpawn <1 then
			timer.Clear("SpawnAI")
		end		
		
		-- we may be over numbers for a bit until the excess AI are killed
	end
	--]]
end

function hunteeringdeathmatch:OnCharacterDied(Character, CharacterController, KillerController)
	if CharacterController ~= nil and KillerController ~= nil then
		local KillerPlayerState = nil
		local KilledPlayerState = nil
		local KillerName = 'Bot'
		local KilledName = 'Bot'
		
		if not actor.HasTag(CharacterController, self.BotTag) then
			KilledPlayerState = player.GetPlayerState(CharacterController)
			KilledName = player.GetName(KilledPlayerState)
		end

		if not actor.HasTag(KillerController, self.BotTag) then
			KillerPlayerState = player.GetPlayerState(KillerController)
			KillerName = player.GetName(KillerPlayerState)
		end
		
		
		timer.Set("DelayedDeathMessage", self, self.DelayedDeathMessage, 3.0, false)
		
		--gamemode.BroadcastGameMessage(KillerName .. " killed " .. KilledName, "Lower", 3.0)
		

		local PlayersWithLives = gamemode.GetPlayerListByLives(self.PlayerTeams.Deathmatch.TeamId, 1, true) -- based off previous deathmatch code
		--print("---------THERE ARE " .. #PlayersWithLives .. " PLAYERS alive")

		if CharacterController == KillerController then
			print("hunteering: awarded no points to player " .. KillerName .. " for a suicide")
			-- no points for killing yourself
		elseif KillerPlayerState then
			player.AwardPlayerScore( KillerPlayerState, "Kills", 1 )
			--print("hunteering: awarded 1 kill point to player " .. player.GetName(KillerPlayerState))
		end

		if actor.HasTag(CharacterController, self.BotTag) then
			timer.Set("CheckEndRound", self, self.CheckDeathCountTimer, 1.0, false)
			--print(KillerName .. " has killed a bot")
		else
			player.SetLives(CharacterController, player.GetLives(CharacterController) - 1)
			
			if #PlayersWithLives < 3 and self.Settings.PlayerTeamUp.Value == 1 then
				self:CheckDeathCountTimer()
			
			elseif #PlayersWithLives < 2 then
				self:CheckDeathCountTimer()
				-- call immediately because round is about to end and nothing more can happen
			else
				timer.Set("CheckEndRound", self, self.CheckDeathCountTimer, 1.0, false)
			end
		end
	end
end


function hunteeringdeathmatch:LogOut(Exiting)
	if gamemode.GetRoundStage() == "PreRoundWait" or gamemode.GetRoundStage() == "InProgress" then
		timer.Set("CheckForCount", self, self.CheckDeathCountTimer, 1.0, false);
	end
end

function hunteeringdeathmatch:DelayedDeathMessage()

	if gamemode.GetRoundStage() == "InProgress" then
		gamemode.BroadcastGameMessage("An enemy was killed ", "Lower", 3.0)
	end

end

function hunteeringdeathmatch:CheckDeathCountTimer()

	-- IR code timer rechecking for how many bots and players are still alive
	local OpForControllers = ai.GetControllers('GroundBranch.GBAIController', self.BotTag, 255, 255)
	print("---------[Timer] THERE ARE " .. #OpForControllers .. " BOTS alive")
	
	local PlayersWithLives = gamemode.GetPlayerListByLives(self.PlayerTeams.Deathmatch.TeamId, 1, true)
	print("---------[Timer] THERE ARE " .. #PlayersWithLives .. " PLAYERS alive")
	
	if self.Settings.BotCount.Value > 0 then
	
		if self.Settings.PlayerTeamUp.Value == 1 then
			if #OpForControllers < 1 and #PlayersWithLives < 3 then -- all bots and extra players have been killed
				gamemode.AddGameStat("Result=None")
				gamemode.AddGameStat("Summary=PlayersEliminated")
				gamemode.SetRoundStage("PostRoundWait")
			elseif #PlayersWithLives < 2 then -- all extra players have been killed. NOTE: These two players might be opposing players which means the extraction will fail
				gamemode.AddGameStat("Result=None")
				gamemode.AddGameStat("Summary=PlayersEliminated")
				gamemode.SetRoundStage("PostRoundWait")
			end

		elseif #OpForControllers < 1 and #PlayersWithLives < 2 then
			gamemode.AddGameStat("Result=Team1")
			gamemode.AddGameStat("Summary=OpForEliminated")
			gamemode.AddGameStat("CompleteObjectives=OptionalKillAllOpposition")
			gamemode.SetRoundStage("PostRoundWait")
		elseif #PlayersWithLives < 1 then
			gamemode.AddGameStat("Result=None")
			gamemode.AddGameStat("Summary=PlayersEliminated")
			gamemode.SetRoundStage("PostRoundWait")
		end
	else -- game without bots or all bots have been killed
		if #PlayersWithLives < 3 and self.Settings.PlayerTeamUp.Value == 1 then
			gamemode.AddGameStat("Result=None")
			gamemode.AddGameStat("Summary=PlayersEliminated")
			gamemode.SetRoundStage("PostRoundWait")
		
		elseif #PlayersWithLives < 2 then
			gamemode.AddGameStat("Result=Team1")
			gamemode.AddGameStat("Summary=OptionalKillAllOpposition")
			gamemode.AddGameStat("CompleteObjectives=OptionalKillAllOpposition")
			gamemode.SetRoundStage("PostRoundWait")
		end
	end
end


function hunteeringdeathmatch:OnRoundStageTimeElapsed(RoundStage)
	if RoundStage == "InProgress" then
		gamemode.AddGameStat("Result=None") -- " .. self.PlayerTeams.Deathmatch.TeamId)
		gamemode.AddGameStat("Summary=ReachedTimeLimit")
		--gamemode.AddGameStat("CompleteObjectives=KillEveryone")
		
	--	local BestFraggers = self:GetBestFraggers()

		-- then award won round score (because there may be joint winners)
	--	for _, PlayerState in ipairs(BestFraggers) do
	--		player.AwardPlayerScore( PlayerState, "WonRound", 1 )
	--	end
		
		gamemode.SetRoundStage("PostRoundWait")
		
		return true
	end
end




function hunteeringdeathmatch:ReportError(ErrorMessage)
	gamemode.BroadcastGameMessage("Error! " .. ErrorMessage, "Upper", 5.0)
	print("-- IntelRetrieval game mode error!: " .. ErrorMessage)
end

function hunteeringdeathmatch:OnGameTriggerBeginOverlap(GameTrigger, Character)
	
	if player.HasItemWithTag(Character, self.LaptopTag) == true and gamemode.GetRoundStageTime() < self.Settings.ExfilTime.Value * 60 then
		if self.Settings.PlayerTeamUp.Value == 1 then
			timer.Set("CheckOpForExfil", self, self.CheckOpForExfilTimer, 1.0, true)
		else
			gamemode.AddGameStat("Result=Team1")
			gamemode.AddGameStat("Summary=IntelRetrieved")
			gamemode.AddGameStat("CompleteObjectives=RetrieveIntel,BeOnExtractionAtTheTimeLimit")
			--gamemode.AddGameStat("Optional:KillAllOpposition")
			gamemode.SetRoundStage("PostRoundWait")
		end

	elseif player.HasItemWithTag(Character, self.LaptopTag) == true and gamemode.GetRoundStageTime() > self.Settings.ExfilTime.Value * 60 then
		gamemode.BroadcastGameMessage("Movement spotted near extraction", "Lower", 2.0)
		player.ShowGameMessage(Character, "TooEarly", "Lower", 7.0)

	end
end


function hunteeringdeathmatch:CheckOpForExfilTimer()
	local Overlaps = actor.GetOverlaps(self.ExtractionPoints[self.ExtractionPointIndex], 'GroundBranch.GBCharacter')
	local PlayersWithLives = gamemode.GetPlayerListByLives(self.PlayerTeams.Deathmatch.TeamId, 1, false)
	
	local bExfiltrated = false
	local bLivingOverlap = false
	local bLaptopSecure = false
	local PlayerWithLapTop = nil

	for i = 1, #PlayersWithLives do
		bExfiltrated = false

		local PlayerCharacter = player.GetCharacter(PlayersWithLives[i])
		
	
		-- May have lives, but no character, alive or otherwise.
		if PlayerCharacter ~= nil then
			for j = 1, #Overlaps do
				if Overlaps[j] == PlayerCharacter then  -- NOTE: needs to be changed to two players only
					bLivingOverlap = true
					bExfiltrated = true
					if player.HasItemWithTag(PlayerCharacter, self.LaptopTag) then
						bLaptopSecure = true
						PlayerWithLapTop = PlayersWithLives[i]
					end
					break
	--			else
	--				print("Trying to exfil")
	--				PlayerWithLapTop = PlayersWithLives[i]
	--				player.ShowGameMessage(PlayerWithLapTop, "PlayerTeamUp", "Upper", 5.0)
				end
			end
		end

		if bExfiltrated == false then
			break
		end
	end
	
	if bLaptopSecure then
		if bExfiltrated then
		 	timer.Clear(self, "CheckOpForExfil")
		 	gamemode.AddGameStat("Result=Team1")
		 	gamemode.AddGameStat("Summary=IntelRetrieved")
			gamemode.AddGameStat("CompleteObjectives=RetrieveIntel,BeOnExtractionAtTheTimeLimit")
		 	gamemode.SetRoundStage("PostRoundWait")
		elseif PlayerWithLapTop ~= nil and self.TeamExfilWarning == false then
			--player.ShowGameMessage(PlayerWithLapTop, "PlayerTeamUp", "Upper", 5.0)
			self.TeamExfilWarning = true
		end
	end
end


function hunteeringdeathmatch:OnTargetCaptured()
	-- this is called from the laptop IntelTarget.lua script when a laptop is successfully hacked

	actor.SetActive(self.ExtractionPoints[self.ExtractionPointIndex], true)
	-- turn on the extraction flare

end

function hunteeringdeathmatch:OnLaptopPickedUp()
	-- laptop has been picked up, so disable proximity alert 
	--print("OnLaptopPickedUp() called")
	
	if self.Settings.ProximityAlert.Value == 1  then
		gamemode.SetObjectiveLocation( nil ) 
	end
end


function hunteeringdeathmatch:OnLaptopPlaced(NewLaptop)
	-- called when the laptop is dropped or replaced (e.g. carrier is killed)
	-- want to start the proximity alert again at its location
	
	-- (this is redundant the first time the laptop is captured)
	
	--print("OnLaptopPlaced() called")

	return
	-- this isn't working so let's just turn it off for now
	
	--if self.Settings.ProximityAlert.Value == 1 and NewLaptop ~= nil then
	--	local NewLaptopLocation = actor.GetLocation( NewLaptop )
	--	if NewLaptopLocation ~= nil then
	--		gamemode.SetObjectiveLocation( NewLaptopLocation ) 
	--		print("Resetting objective location to (" .. NewLaptopLocation.x .. ", " .. NewLaptopLocation.y .. ", " .. NewLaptopLocation.z .. ")")
	--	end
	--end
end


function hunteeringdeathmatch:OnMissionSettingChanged(Setting, NewValue)
	-- NB this may be called before some things are initialised
	-- need to avoid infinite loops by setting new mission settings
	
		local AllInsertionPoints = gameplaystatics.GetAllActorsOfClass('GroundBranch.GBInsertionPoint')

		for i, InsertionPoint in ipairs(AllInsertionPoints) do
			-- any insertion point matching a tag of the extraction point will be disabled (i.e. is in proximity)
			
			if actor.GetTeamId(InsertionPoint) == self.PlayerTeams.Deathmatch.TeamId then
				local InsertionPointName = gamemode.GetInsertionPointName(InsertionPoint)
				
				if self.Settings.PlayerTeamUp.Value == 1 then
					bActive = true
		--		elseif actor.HasTag( self.ExtractionPoints[self.ExtractionPointIndex], InsertionPointName) then
		--			bActive = false
				else 
					bActive = false
				end

				actor.SetActive(InsertionPoint, bActive)
				actor.SetTeamId(InsertionPoint, self.PlayerTeams.Deathmatch.TeamId)
			end
		end

	if Setting == 'DisplaySearchLocations' then
		self:RandomiseObjectives()
	end
end


return hunteeringdeathmatch